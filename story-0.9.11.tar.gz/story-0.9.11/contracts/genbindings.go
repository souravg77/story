//go:generate make bindings
//go:generate make examples-bindings

package contracts
