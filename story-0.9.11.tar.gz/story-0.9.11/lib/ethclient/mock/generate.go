//go:generate mockgen -source ../ethclient_gen.go -package mock -destination ./mock_interfaces.go
package mock
