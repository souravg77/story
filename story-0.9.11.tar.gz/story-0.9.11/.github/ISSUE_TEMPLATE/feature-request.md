---
name: Feature Request
about: Create a feature request item to be picked up by a contributor.
title: ''
labels: 'enhancement'
assignees: ''

---

## Description and context
<!--- Write a description or todo list as the scope. A task should be: -->
<!--- Actionable: can be acted on right away. -->
<!--- Clearly defined scope: has precise limits/boundaries. -->
<!--- Small scope: break complex tasks into smaller ones if they involve multiple system parts, multiple people/PRs, or parallelizable work. -->

## Suggested solution
<!--- Optionally write a description of suggested solution for this feature request -->

## Definition of done
<!--- Describe completion: e.g. code merged, deployment is done, or release published etc. -->
