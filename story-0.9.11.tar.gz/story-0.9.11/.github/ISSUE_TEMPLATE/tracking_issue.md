---
name: Tracking issue
about: Tracking issues are task lists used to better organize regular work items.
title: 'Tracking issue for *ADD_PROJECT* - *ADD_COMPONENT*'
labels: 'epic'
assignees: ''

---

This issue is for grouping *ADD_COMPONENT* related tasks that are necessary for *ADD_PROJECT*.

### Other tracking issues for the same project:
<!--- Link related tracking issues within the project for easier navigation. -->
<!--- Assign tasks to the appropriate tracking issue if there is more than one. -->

- #XXXX
- #XXXX
- #XXXX

<!--- Subtasks MUST be inside the ``` -> ``` code block. -->
```[tasklist]
### Task list
- [ ] XXXX
- [ ] XXXX
```
