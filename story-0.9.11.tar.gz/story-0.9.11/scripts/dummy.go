// Package scripts is a empty go package only used for the tools.go pattern.
// This file is required for go test ./... to work.
package scripts
