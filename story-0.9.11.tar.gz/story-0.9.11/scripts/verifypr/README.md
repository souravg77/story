# verifypr

Simple script that is called by [verifypr](../../.github/workflows/verifypr.yml) github action
that verifies story PRs against the conventional commit template.

See supported types [here](https://github.com/conventional-changelog/commitlint/tree/master/%40commitlint/config-conventional#type-enum)
